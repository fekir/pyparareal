#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
 pyparareal: un codice python per testare il metodo parareal

 Copyright (C) 2013-2014 Federico Paolo Kircheis

 This file is part of pyparareal.

 pypareal is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Librerie
import math								# contiene operatori matematici, come ad esempio exp
import numpy							# contiene comandi simili a matlab, ad esempio power, zeros, ...

def fun(es, par=1): # u' = f(u)
	if (es == 'PROBMOD'): # PROBMOD: y' = par y | lineare, autonomo, dissipativo
		par  = -abs(par)
		f    = lambda t,y: par*y
		dfy  = lambda t,y: par
		t0   = 0
		tmax = 7/9.0
		y0   = [1]
		sol  = lambda t:  numpy.power(math.e,par*t)
	elif (es== '1D2'): # 1D2 | lineare, non autonomo, dissipativo
		par  = abs(par)
		f    = lambda t,y: -2*par*t*y**2
		dfy  = lambda t,y: -4*par*t*y
		t0   = 0
		tmax = 2
		y0   = [1]
		sol  = lambda t: 1.0/(1+par*(t**2))
	elif (es== '1D3'): # 1D3 | quasi-lineare, non autonomo
		f    = lambda t,y: (t**2)*(1-3*y)
		dfy  = lambda t,y: -3*(t**2)
		t0   = 0
		tmax = 3
		y0   = [2]
		sol  = lambda t: (1+5*numpy.exp(-t**3))/3
	elif (es== '1D4'): # 1D4 | quasi-lineare, non autonomo
		f    = lambda t,y: 3*(y-t)
		dfy  = lambda t,y: 3
		t0   = 0
		tmax = 5
		y0   = [1.0/3]
		sol  = lambda t: t+1.0/3
	elif (es== '1D5'): # 1D5 | quasi-lineare, non autonomo, dissipativo
		f    = lambda t,y: 20*(t-y)+1
		dfy  = lambda t,y: -20
		t0   = 0
		tmax = 5
		y0   = [1]
		sol  = lambda t: t+numpy.exp(-20*t)
	elif (es== '1D6'): # 1D6 | non lineare/quadratico, autonomo, dissipativo
		f    = lambda t,y: -y**2
		dfy  = lambda t,y: -2*y
		t0   = 0
		tmax = 10
		y0   = [5]
		sol  = lambda t: 5.0/(1+5*t)
	elif (es== '1D7'): # 1D7 | quasi-lineare, non autonomo
		f    = lambda t,y: 1-y/(2*numpy.sqrt(t))
		dfy  = lambda t,y: -1/(2*numpy.sqrt(t))
		t0   = 1
		tmax = 20
		y0   = 0
		sol  = lambda t: 2*(numpy.sqrt(t)-1)
	elif (es== '1D8'): # 1D8 | non lineare, non autonomo
		f    = lambda t,y: 2*t*(y+1/y)
		dfy  = lambda t,y: 2*t*(1 -1/(y**2))
		t0   = 0
		tmax = 1
		y0   = -2
		sol  = lambda t: -numpy.sqrt(-1+5*numpy.exp(2*t**2))
	elif (es== '1D9'): # 1D9 | lineare, non autonomo, periodico
		f    = lambda t,y: par*numpy.cos(t)*y
		dfy  = lambda t,y: par*numpy.cos(t)
		t0   = 0
		tmax = 9
		y0   = [1]
		sol  = lambda t: numpy.exp(par*numpy.sin(t));
	elif (es=='BERNOULLI'): # non lineare, non autonomo, dissipativo
		f    = lambda t,y: 2*y/t-t**2*y**2
		dfy  = lambda t,y: 2.0/t-2*t**2*y
		t0   = 1.0/2
		tmax = 2
		y0   = 40.0/33
		sol  = lambda t: (5*t**2)/(t**5+1)
	# Problemi 2D
	elif (es== 'PERIODICO'): # 2.1 # viene da y''+ par**2 y =0, y_0=0, y'_0 = par, ovvero y = sin(par t) | lineare, autonomo
		par  = abs(par)
		f    = lambda t,y: numpy.dot([[0,1], [-1,0]], y)*par
		dfy  = lambda t,y: [[0,par], [-par,0]]
		t0   = 0
		tmax = 7/9.0
		y0   = [0, 1]
		sol  = lambda t:  ([numpy.sin(t*par), numpy.cos(t*par)])
	elif (es== 'PERIODICO2'): # quasi-lineare, non autonomo, periodico (2 periodi)
		par2 = 5.0/2*par
		f    = lambda t,y: numpy.dot([[0,1], [-1,0]], y)*par - [0, ( (par2)**2-(par)**2 )*numpy.sin(par2*t)/(par+0.0)]
		dfy  = lambda t,y: [[0,par], [-par,0]]
		t0   = 0
		tmax = 7/9.0
		y0   = [0, 1+par2/(par+0.0)]
		sol  = lambda t:  ([ numpy.sin(t*par)+numpy.sin(t*par2), numpy.cos(t*par) + par2/(par+0.0)*numpy.cos(t*par2)])
	elif (es== '2D2'): # 2D2 prima componente è sbagliata... | quasi-lineare, no autonomo
		f    = lambda t,y:  numpy.dot([[-4, -2], [3, 1] ],y)+[ numpy.cos(t)+4*numpy.sin(t), -3*numpy.sin(t)]
		dfy  = lambda t,y: [[-4, -2], [3, 1] ]
		t0   = 0
		tmax = 2
		y0   = [0, -1]
		sol  = lambda t: [2*numpy.exp(-t)-2*numpy.exp(-2*t)+3*numpy.sin(t), -3*numpy.exp(-t)+2*numpy.exp(-2*t)]
	elif (es== '2D3'): # 2D3 | quasi-lineare, non autonomo
		f    = lambda t,y: numpy.dot([[0, 1], [-1, 0] ],y)+numpy.transpose([2*t*numpy.sin(t),2*t*numpy.cos(t)])
		dfy  = lambda t,y: [[0, 1], [-1, 0]]
		t0   = 0
		tmax = 2
		y0   = [0, 0]
		sol  = lambda t: [numpy.sin(t)*t**2,numpy.cos(t)*t**2]
	elif (es== 'VDP'):  # VDP: Van der Pool | non lineare, autonomo, stiff, no sol esatta
		par  = abs(par)
		if (par>5):
			par=5
		f    = lambda t,y: numpy.dot([[0,1], [-1,par*(1-y[0]**2)]], y)
		dfy  = lambda t,y: [[0, 1], [-1+2*par*y[0]*y[1], par*(1-y[0]**2)]]
		t0   = 0
		tmax = 20
		y0   = [2,0]
		sol  = lambda t:  [0*t, 0*t]
	return f,dfy,t0,tmax,y0,sol
