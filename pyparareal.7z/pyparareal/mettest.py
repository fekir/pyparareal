#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
 pyparareal: un codice python per testare il metodo parareal

 Copyright (C) 2013-2014 Federico Paolo Kircheis

 This file is part of pyparareal.

 pypareal is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Librerie
import math								# contiene operatori matematici, come ad esempio exp
import numpy							# contiene comandi simili a matlab, ad esempio power, zeros, ...
from matplotlib import pyplot		# per fare plot come matlab
from copy import copy, deepcopy	# per copiare array, altrimenti è un riferimento

import casitest
import metodi

########################################################################
# Parametri #
#############
# kmax è il numero di iterate, num_int è il numero iniziale di intervalli, va poi raddoppiato ad ogni passo
#numfun  = 'PROBMOD'
#numfun  = 'PERIODICO2'
#numfun  = 'VDP'
numfun  = 'BERNOULLI'
par     = 2
kmax    = 1
size=num_int = 32

# dati problema da risolvere, vedi fun
f,dfy,t0,tmax,y0,sol = casitest.fun(numfun,par)
#tmax=101

#G = lambda f,T,y0: metodi.ee(f,T,y0)
#G = lambda f,t0,tmax,num_int,y0: metodi.eiptofisso(f,t0,tmax,num_int,y0)

B,a,c,ordine,esplicito = metodi.RKcomp('RK4')
hmin = (tmax-t0+0.0)/size
hmax = 2*hmin

#G = lambda f,T,y0: metodi.RK(f,T,y0,B,a,c,esplicito,dfy)
#G = lambda f,t0,tmax,num_int,y0: metodi.eiptofisso(f,t0,tmax,num_int,y0,toll=1e-16,nitmax=100)
#G = lambda f,T,y0: metodi.RK45(f,T,y0,dfy,toll=1e-4, nitmax=10, hmax=5)
G = lambda f,T,y0: metodi.RK(f,T,y0,B,a,c,esplicito,dfy)
#G = lambda f,T,y0: metodi.RKada(f,T,y0,B,a,c,ordine,esplicito, dfy, 1e-4, 100, hmin , hmax)

########################################################################

# applico il metodo e preparo grafici
dim = numpy.size(y0)
errG = numpy.zeros((dim,kmax))
h = numpy.zeros(kmax)
# Grafico soluzione
for k in range(0,kmax):
	T = numpy.linspace(t0,tmax,(2**k)*num_int+1)
	print numpy.diff(T)
	T,Y = G(f,T,y0)
	print numpy.diff(T)

	assex  = numpy.linspace(T[0],T[-1],500)
	if (dim<2):
		sol_ex = [sol(assex)]
	else:
		sol_ex = sol(assex)

	h[k]= max(numpy.diff(T))
	for j in range(0,dim):
		errG[j,k] = deepcopy(max(abs(Y-sol(T))[j]))  #devo farli singolarmente
	pyplot.figure(k)
	pyplot.hold(True)
	for j in range(0,dim):
		pyplot.title('Iterata k=%d' %k)
		pyplot.subplot( dim*100+10+(j+1) )
		pyplot.plot(T,Y[j],'b*')
		pyplot.plot(assex,sol_ex[:][j],'r')
	pyplot.hold(False)

# Grafico errore
pyplot.figure(k+1)
pyplot.hold(True)
for j in range(0,dim):
	pyplot.plot(range(0,kmax),errG[j],'-o')
pyplot.title('Grafico Errori')
pyplot.yscale('log')
pyplot.hold(False)


# Calcolo ordine convergenza
lerr = numpy.log(errG)
lh   = numpy.log(h)
p = numpy.diff(lerr)/numpy.diff(lh)
print "ordine:"
print p
print "errore massimo: %f" % numpy.max(errG)

pyplot.show()
