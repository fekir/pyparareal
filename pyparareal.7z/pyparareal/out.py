#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
 pyparareal: un codice python per testare il metodo parareal

 Copyright (C) 2013-2014 Federico Paolo Kircheis

 This file is part of pyparareal.

 pypareal is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Librerie
import math								# contiene operatori matematici, come ad esempio exp
import numpy							# contiene comandi simili a matlab, ad esempio power, zeros, ...
from matplotlib import pyplot		# per fare plot come matlab
from copy import copy, deepcopy	# per copiare array, altrimenti è un riferimento
#from mpi4py import MPI				# per lavorare con MPI
from matrix2latex import matrix2latex

import testf

########################################################################
# Parametri
directory= "/home/df0/Documenti/uni/Tesi/testo/risultati/tmp/"   # se non voglio salvare usare savef#directory= "/nasfc/studenti/2014/fkircheis/mpi_python/result/"   # se non voglio salvare usare savef
savef    =  True			# salva immagini e tabelle
vis_img  = not True			# per salvare su file dati che servono per vedere immaginis
vis_tab  = not True

########################################################################
# Carico dati
try:
	Y_glob  = numpy.load(directory+"Y_glob.npy")
	T_glob  = numpy.load(directory+"T_glob.npy")
	TF_glob = numpy.load(directory+"TF_glob.npy")
	YF_glob = numpy.load(directory+"YF_glob.npy")
	numfun  = numpy.load(directory+"numfun.npy")
	par     = numpy.load(directory+"par.npy")
	size    = numpy.load(directory+"size.npy") # da determinare da YF!
	YS_glob = numpy.load(directory+"YS_glob.npy")
except:
		print "------------------------------------------------------------------------\nNon sono riuscito a caricare dei dati, esegui lo script parareal con il comando\n mpirun -np X python parareal.py\ndove X è il numero di processori desiderato, strettamente maggiore di uno.\nSe tale script si trova in una cartella diversa copiare i file\n Y_glob.npy, T_glob.npy, YF_glob.npy, TF_glob.npy\n"
		quit()

########################################################################
kmax = numpy.shape(Y_glob)[1]-1
f,dfy,t0,tmax,y0,sol = testf.fun(numfun,par)
dim = numpy.size(y0)
# aggiustamenti
tmax = T_glob[-1]

########################################################################
# Errori
if( (vis_tab) | (savef) | (vis_img) ):  # mostra info errori
	print "Info su errore e ordine di convergenza."
	kmax = numpy.shape(Y_glob)[1]-1
	errG = numpy.zeros((dim,kmax+1,numpy.size(T_glob)))
	err2G = numpy.zeros((dim,kmax+1,numpy.size(T_glob)))

	for k in range(0,kmax+1):  # creo array contenente errori
		errG[:,k,:]  = deepcopy(abs(Y_glob[:,k,:]-sol(T_glob)))
		err2G[:,k,:] = deepcopy(abs(Y_glob[:,k,:]-YS_glob[:,:]))

	#numpy.save("errG", errG)

	# Calcolo ordine convergenza--> solo una dimensione
	h     = max(numpy.diff(T_glob))
	lerr  = numpy.log(errG[0,:,1:])  #tolgo primo el che coincide con dato iniziale (e quindi err=0)
	lerr2 = numpy.log(err2G[0,:,1:])
	lh    = numpy.log(h)
	if (savef):
		nameerr=directory+"err.tex"
	else:
		nameerr=None
	M = matrix2latex(
		(	numpy.concatenate( (['$e_{1,k}$'], errG[0,:,-1].astype(object))),
			numpy.concatenate( (['$e_{2,k}$'], err2G[0,:,-1].astype(object))),
			numpy.concatenate( (['$le_{1,k}/lh$'], lerr[:,-1]/lh.astype(object))),
			numpy.concatenate( (['$le_{2,k}/lh$'], lerr2[:,-1]/(lh).astype(object))),
			numpy.concatenate( (['$le_{1,k}/(lh(k+1))$'], lerr[:,-1]/(lh*numpy.arange(1,kmax+2,1)).astype(object))),
			numpy.concatenate( (['$le_{2,k}/(lh(k+1))$'], lerr2[:,-1]/(lh*numpy.arange(1,kmax+2,1)).astype(object))),
			numpy.concatenate( (['$dle_{1,k+1}/lh$'], numpy.diff(lerr[:,-1])/(lh).astype(object))),
			numpy.concatenate( (['$dle_{2,k+1}/lh$'], numpy.diff(lerr2[:,-1])/(lh).astype(object)))
		),nameerr, "table", "center", "small", "tabular",  caption='Errore con $p=%d$ processori' % size, headerRow = ['k']+range(0,kmax+1), position ="H",
	)
	if(vis_tab):
		print M
		print "------------------------------------------------------------------------"

#end if( (vis_tab) | (savef) | (vis_img) )

########################################################################

# Grafici
if ((vis_img) | (savef)):
	from matplotlib import pyplot		# per fare plot come matlab

	assex  = numpy.linspace(T_glob[0],T_glob[-1], 50*size)
	if (dim<2):
		sol_ex = [sol(assex)]
	else:
		sol_ex = sol(assex)

	num_fig = 0
	# creo plot da salvare e/o mostrare
	for num_fig in range(0,min(kmax, 10)):
		pyplot.figure(num_fig)
		pyplot.hold(True)
		#creo subplot
		for j in range(0,dim):
			#pyplot.title('Iterata k = %d' %num_fig)
			ax = pyplot.subplot( dim*100+10+(j+1) )
			ax.plot([],[],'go',label='Soluzione UF')
			ax.plot(numpy.transpose(TF_glob),YF_glob[:,num_fig,:,:][j],'go')
			ax.plot(T_glob,Y_glob[j,num_fig,:],'b*',label='Soluzione $U^{%d}$' %num_fig)
			ax.plot(assex,sol_ex[:][j],'r',label='Soluzione esatta $u(t)$')
		box = ax.get_position()
		ax.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
		ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=5)
		pyplot.hold(False)
		if (savef):
			namefig = directory+"fig%.2d.png" % num_fig
			pyplot.savefig(namefig)
	#end for num_fig in range(0,kmax):

	num_fig+=1

	pyplot.figure(num_fig) #per questo qua non ho la soluzione fine! ultimo passo calcola solo la grossolana
	pyplot.hold(True)
	for j in range(0,dim):
		#pyplot.title('Iterata k = %d' %num_fig)
		ax = pyplot.subplot( dim*100+10+(j+1) )
		ax.plot(T_glob,Y_glob[j,-1,:],'b*',label='Soluzione $U^{%d}$'  %num_fig)
		ax.plot(assex,sol_ex[:][j],'r',label='Soluzione esatta $u(t)$')
	box = ax.get_position()
	ax.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
	ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=5)
	pyplot.hold(False)
	if (savef):
		namefig = directory+"fig%.2d.png" % num_fig
		pyplot.savefig(namefig)

	if(num_fig>0):
		num_fig+=1

	# Errore vs esatta
	pyplot.figure(num_fig)
	pyplot.hold(True)
	for j in range(0,dim):
		#pyplot.title('Grafico Errori')
		ax = pyplot.subplot( dim*100+10+(j+1) )
		ax.plot(range(0,kmax+1),errG[j],'-o')
		pyplot.yscale('log')
		#pyplot.ylabel('Logaritmo dell\'errore\ncon soluzione esatta')
		#pyplot.xlabel('Numero di iterate')
	if(dim==2): # non riesco a farlo modulare...
		ax.set_ylabel(r"Logaritmo dell'errore $\|U_n^k - u(t_n)\|$", horizontalalignment = 'left')
	elif(dim==1):
		ax.set_ylabel(r"Logaritmo dell'errore $\|U_n^k - u(t_n)\|$", horizontalalignment = 'center')
	ax.set_xlabel(r'Numero di iterate $k$')
	#box = ax.get_position()
	#ax.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
	#ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=5)
	pyplot.hold(False)
	if (savef):
		namefig = directory+"fig_err.png"
		pyplot.savefig(namefig)

	# Errore vs fine
	pyplot.figure(num_fig+1)
	pyplot.hold(True)
	for j in range(0,dim):
		#pyplot.title('Grafico Errori')
		ax = pyplot.subplot( dim*100+10+(j+1) )
		ax.plot(range(0,kmax+1),err2G[j],'-o')
		pyplot.yscale('log')
		#pyplot.ylabel('Logaritmo dell\'errore\ncon soluzione fine')
		#pyplot.xlabel('Numero di iterate')
	if(dim==2): # non riesco a farlo modulare...
		ax.set_ylabel(r"Logaritmo dell'errore $\|U_n^k - U_n^N\|$", horizontalalignment = 'left')
	elif(dim==1):
		ax.set_ylabel(r"Logaritmo dell'errore $\|U_n^k - U_n^N\|$", horizontalalignment = 'center')
	ax.set_xlabel(r'Numero di iterate $k$')
	#box = ax.get_position()
	#ax.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
	#ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=5)
	pyplot.hold(False)

	if (savef):
		namefig = directory+"fig_err2.png"
		pyplot.savefig(namefig)

	if(vis_img):
		pyplot.show()
#end if ( (rank==0) & ((vis_img) | (savef)) )

########################################################################
