#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
 pyparareal: python code for testing the parareal method

 Copyright (C) 2013-2014 Federico Paolo Kircheis

 This file is part of pyparareal.

 pypareal is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# vedi --> https://www.gnu.org/licenses/gpl-howto.html

# Librerie
import math										# contiene operatori matematici, come ad esempio exp
import numpy									# contiene comandi simili a matlab, ad esempio power, zeros, ...
import time										# vedere se presente in uni per calcolare temi esecuzione
#from matplotlib import pyplot				# per fare plot come matlab, importato successivamente con un if
from copy import copy, deepcopy			# per copiare array, altrimenti è un riferimento
from mpi4py import MPI						# per lavorare con MPI
from matrix2latex import matrix2latex	# per scrittura tabelle latex --> mettere pacchetto nella stessa cartella

# miei moduli
import prop
import testf
import parareal

size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
name = MPI.Get_processor_name()

########################################################################
# Imposto variabili per i metodi
directory= "/home/df0/Documenti/uni/Tesi/testo/risultati/tmp/"   # se non voglio salvare usare savef
#directory= "/nasfc/studenti/2014/fkircheis/pyparareal/result/"   # se non voglio salvare usare savef
savef    = True			# salva immagini e tabelle
vis_img  = not True			# per salvare su file dati che servono per vedere immaginis
vis_tab  = not True
kkmax=1						# nr di volte di eseguire parareal (per prendere tempi)
num_int  = size			# numero intervalli --> non serve più, ma al momento tengo
num_intF = 1000			# numero intervalli partiz fine
kmax     = size			# numero massimo di iterate in k, serve >=1
par      = 1
#numfun   = 'PROBMOD'
numfun   = 'PERIODICO2'
#numfun   = '1D9'
#numfun   = 'VDP'

# dati problema da risolvere, vedi fun
f,dfy,t0,tmax,y0,sol = testf.fun(numfun,par)
tmax = tmax*10
# Propagatori G e F
RKI='BUTCHERLOBATTO'
RKG=RKI
RKF='MERSON'


BI,aI,cI,ordineI,esplicitoI = prop.RKcomp(RKI)
# se uso I adattivo, arrivo almeno a tmax con passo hmin (come non adattivo), al più supero tmax
hmin = (tmax-t0+0.0)/(size)
hmin = 0.2
hmax = 6*hmin
I = lambda f,T,y0: prop.RKada(f,T,y0,BI,aI,cI,ordineI,esplicitoI, dfy, 10*((hmin+hmax)/2)**ordineI, 100, hmin, hmax)
I = lambda f,T,y0: prop.RKada(f,T,y0,BI,aI,cI,ordineI,esplicitoI, dfy, 1e-3, 100, hmin, hmax)

BG,aG,cG,ordineG,esplicitoG = prop.RKcomp(RKG)
G = lambda f,T,y0: prop.RK(f,T,y0,BG,aG,cG,esplicitoG,dfy)
I=G

BF,aF,cF,ordineF,esplicitoF = prop.RKcomp(RKF)
F = lambda f,T,y0: prop.RK(f,T,y0,BF,aF,cF,esplicitoF,dfy)

toll = (((tmax-t0+0.0)/size)/num_intF)**(ordineF)    # ~ h_F^ordine
toll = 10*(((tmax-t0+0.0)/size)/num_intF)**(ordineF)    # ~ h_F^ordine
#toll = -1

#F = lambda f,t0,tmax,num_int,y0: prop.ee(f,t0,tmax,num_int,y0)
#G = lambda f,t0,tmax,num_int,y0: prop.ee(f,t0,tmax,num_int,y0)

########################################################################
dim = numpy.size(y0)
#kmax = max(min(size+1,int(kmax)),1)  # inutile farne piu' di kmax e meno di 1

if (rank==0): # messaggio di routine
	print "------------------------------------------------------------------------"
	print "pyparareal  Copyright (C) 2013-2014  Federico Paolo Kircheis"
	print "This program comes with ABSOLUTELY NO WARRANTY."
	print "This is free software, and you are welcome to redistribute it"
	print "under certain conditions; read the license for details."
	print "------------------------------------------------------------------------"
	print "Stai usando l'algoritmo parareal con"
	print " - Numero processori (e intervalli): %d, di ampiezza %f" % (size,(tmax-t0+0.0)/size)
	print " - Numero intervalli fini: %d, di ampiezza %f" % (num_intF, ((tmax-t0+0.0)/size)/num_intF )
	print " - Numero iterate massimo: %d" % (kmax)
	print " - tolleranza: %f" % (toll)
	print "Propagatori scelti:\n - G -> %s\n - F -> %s" % (RKG,RKF)
	print "Funzione test _%s_ con parametro _%f_" % (numfun, par)
	print "------------------------------------------------------------------------"

########################################################################
########################################################################
# Applico metodo parareal e salvo tempi
maxtime=mintime=sumtime=0.0
for kk in range(0,kkmax):
	start = time.clock()
	T_glob,Y_glob,TF_glob,YF_glob = parareal.kernel(f,t0,tmax,y0,num_int,num_intF,kmax,I,G,F,toll)
	elapsed = (time.clock() - start)
	tmpmaxtime = MPI.COMM_WORLD.reduce(elapsed, op=MPI.MAX, root=0)
	tmpmintime = MPI.COMM_WORLD.reduce(elapsed, op=MPI.MIN, root=0)
	tmpsumtime = MPI.COMM_WORLD.reduce(elapsed, op=MPI.SUM, root=0)

	if (rank==0):
		maxtime = maxtime + tmpmaxtime
		mintime = mintime + tmpmintime
		sumtime = sumtime + tmpsumtime
#end for kk in range(0,kkmax):
maxtime = maxtime/kkmax
mintime = mintime/kkmax
sumtime = sumtime/kkmax
########################################################################
# Soluzione fine
if (rank==0):
	serialtime=0.0
	for kk in range(0,kkmax):
		start = time.clock()
		YS_glob = numpy.zeros((dim,size+1))
		YS_glob[:,0] = y0
		for jj in range(1,size+1):   # sfrutto il fatto che uso metodi ad un passo --> da cambiare se uso multistep
			TS,YS = F(f, TF_glob[jj-1], YS_glob[:,jj-1])
			YS_glob[:,jj]= YS[:,-1]
		elapsed = (time.clock() - start)
		serialtime = serialtime + elapsed
	#end for kk
	serialtime = serialtime/kkmax
########################################################################
# Errori
if( (rank==0) & ( (vis_tab) | (savef) | (vis_img) ) ):  # mostra info errori
	print "Info su errore e ordine di convergenza."
	kmax = numpy.shape(Y_glob)[1]-1
	errG = numpy.zeros((dim,kmax+1,numpy.size(T_glob)))
	err2G = numpy.zeros((dim,kmax+1,numpy.size(T_glob)))

	for k in range(0,kmax+1):  # creo array contenente errori
		errG[:,k,:] = deepcopy(abs(Y_glob[:,k,:]-sol(T_glob)))
		err2G[:,k,:] = deepcopy(abs(Y_glob[:,k,:]-YS_glob[:,:]))

	# Calcolo ordine convergenza--> solo una dimensione
	h     = max(numpy.diff(T_glob))
	lerr   = numpy.log(errG[0,:,1:])  #tolgo primo el che coincide con dato iniziale (e quindi err=0)
	lerr2 = numpy.log(err2G[0,:,1:])
	lh    = numpy.log(h)
	if (savef):
		nameerr=directory+"err.tex"
	else:
		nameerr=None
	M = matrix2latex(
		(	numpy.concatenate( (['$e_{1,k}$'], errG[0,:,-1].astype(object))),
			numpy.concatenate( (['$e_{2,k}$'], err2G[0,:,-1].astype(object))),
			numpy.concatenate( (['$le_{1,k}/lh$'], lerr[:,-1]/lh.astype(object))),
			numpy.concatenate( (['$le_{2,k}/lh$'], lerr2[:,-1]/(lh).astype(object))),
			numpy.concatenate( (['$le_{1,k}/(lh(k+1))$'], lerr[:,-1]/(lh*numpy.arange(1,kmax+2,1)).astype(object))),
			numpy.concatenate( (['$le_{2,k}/(lh(k+1))$'], lerr2[:,-1]/(lh*numpy.arange(1,kmax+2,1)).astype(object))),
			numpy.concatenate( (['$dle_{1,k+1}/lh$'], numpy.diff(lerr[:,-1])/(lh).astype(object))),
			numpy.concatenate( (['$dle_{2,k+1}/lh$'], numpy.diff(lerr2[:,-1])/(lh).astype(object)))
		),nameerr, "table", "center", "small", "tabular",  caption='Errore con $p=%d$ processori' % size, headerRow = ['k']+range(0,kmax+1), position ="H",
	)
	if(vis_tab):
		print M
		print "------------------------------------------------------------------------"

#end if( (rank==0) & ( (vis_tab) | (savef) | (vis_img) ) )

########################################################################
# Tempi
if( (rank==0) & ((savef) | (vis_tab)) ):  # salva/mostra tempi
	if (savef):
		nametimefile=directory+"tempi.tex"
	else:
		nametimefile=None
	T = matrix2latex(
		(	[ size,mintime, maxtime,sumtime/size, serialtime]
		),nametimefile, "table", "center", "small", "tabular",  caption='Errore con $p=%d$ processori' % size, headerRow = ['numero processori','tempo minimo','tempo massimo', 'tempo medio','tempo seriale'], position ="H", transpose=True
	)
	if(vis_tab):
		print T
		print "------------------------------------------------------------------------"
elif (rank==0):
	print 'Tempi di esecuzione'
	print ' - Tempo minimo:  %.5f' % (mintime)
	print ' - Tempo massimo: %.5f' % (maxtime)
	print ' - Tempo medio:   %.5f' % (sumtime/size)
	print ' - Tempo seriale: %.5f' % (serialtime)
	print "------------------------------------------------------------------------"
#end if( (rank==0) & (savef) ):  # salva/mostra tempi

########################################################################
# Grafici
if ( (rank==0) & ((vis_img) | (savef)) ):
	from matplotlib import pyplot		# per fare plot come matlab
	pyplot.rc('text', usetex=True)

	assex  = numpy.linspace(T_glob[0],T_glob[-1], 50*size)
	if (dim<2):
		sol_ex = [sol(assex)]
	else:
		sol_ex = sol(assex)

	num_fig = 0
	# creo plot da salvare e/o mostrare
	for num_fig in range(0,min(kmax, 10)):
		pyplot.figure(num_fig)
		pyplot.hold(True)
		#creo subplot
		for j in range(0,dim):
			#pyplot.title('Iterata k = %d' %num_fig)
			ax = pyplot.subplot( dim*100+10+(j+1) )
			ax.plot([],[],'go',label='Soluzione UF')
			ax.plot(numpy.transpose(TF_glob),YF_glob[:,num_fig,:,:][j],'go')
			ax.plot(T_glob,Y_glob[j,num_fig,:],'b*',label=r'Soluzione $U^{%d}$' %num_fig)
			ax.plot(assex,sol_ex[:][j],'r',label='Soluzione esatta $u(t)$')
		box = ax.get_position()
		ax.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
		ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=5)
		pyplot.hold(False)
		if (savef):
			namefig = directory+"fig%.2d.png" % num_fig
			pyplot.savefig(namefig)
	#end for num_fig in range(0,kmax):

	num_fig+=1

	pyplot.figure(num_fig) #per questo qua non ho la soluzione fine! ultimo passo calcola solo la grossolana
	pyplot.hold(True)
	for j in range(0,dim):
		#pyplot.title('Iterata k = %d' %num_fig)
		ax = pyplot.subplot( dim*100+10+(j+1) )
		ax.plot(T_glob,Y_glob[j,-1,:],'b*',label=r'Soluzione $U^{%d}$' %num_fig)
		ax.plot(assex,sol_ex[:][j],'r',label='Soluzione esatta $u(t)$')
	box = ax.get_position()
	ax.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
	ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=5)
	pyplot.hold(False)
	if (savef):
		namefig = directory+"fig%.2d.png" % num_fig
		pyplot.savefig(namefig)

	if(num_fig>0):
		num_fig+=1

	# Errore vs esatta
	pyplot.figure(num_fig)
	pyplot.hold(True)
	for j in range(0,dim):
		#pyplot.title('Grafico Errori')
		ax = pyplot.subplot( dim*100+10+(j+1) )
		ax.plot(range(0,kmax+1),errG[j],'-o')
		pyplot.yscale('log')
		#pyplot.ylabel('Logaritmo dell\'errore\ncon soluzione esatta')
		#pyplot.xlabel('Numero di iterate')
	if(dim==2): # non riesco a farlo modulare...
		ax.set_ylabel(r"Logaritmo dell'errore $\|U_N^k - u(t_N)\|$", horizontalalignment = 'left')
	elif(dim==1):
		ax.set_ylabel(r"Logaritmo dell'errore $\|U_N^k - u(t_N)\|$", horizontalalignment = 'center')
	ax.set_xlabel(r'Numero di iterate $k$')
	#box = ax.get_position()
	#ax.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
	#ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=5)
	pyplot.hold(False)
	if (savef):
		namefig = directory+"fig_err.png"
		pyplot.savefig(namefig)

	# Errore vs fine
	pyplot.figure(num_fig+1)
	pyplot.hold(True)
	for j in range(0,dim):
		#pyplot.title('Grafico Errori')
		ax = pyplot.subplot( dim*100+10+(j+1) )
		ax.plot(range(0,kmax+1),err2G[j],'-o')
		pyplot.yscale('log')
		#pyplot.ylabel('Logaritmo dell\'errore\ncon soluzione fine')
		#pyplot.xlabel('Numero di iterate')
	if(dim==2): # non riesco a farlo modulare...
		ax.set_ylabel(r"Logaritmo dell'errore $\|U_N^k - U_N^N\|$", horizontalalignment = 'left')
	elif(dim==1):
		ax.set_ylabel(r"Logaritmo dell'errore $\|U_N^k - U_N^N\|$", horizontalalignment = 'center')
	ax.set_xlabel(r'Numero di iterate $k$')
	#box = ax.get_position()
	#ax.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
	#ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=5)
	pyplot.hold(False)

	if (savef):
		namefig = directory+"fig_err2.png"
		pyplot.savefig(namefig)

	if(vis_img):
		pyplot.show()
#end if ( (rank==0) & ((vis_img) | (savef)) )

########################################################################
# Salva info
if ( (rank==0) & (savef) ):
	numpy.save(directory+"Y_glob", Y_glob)
	numpy.save(directory+"T_glob", T_glob)
	numpy.save(directory+"TF_glob", TF_glob)
	numpy.save(directory+"YF_glob", YF_glob)
	numpy.save(directory+"numfun", numfun)
	numpy.save(directory+"par", par)
	numpy.save(directory+"size", size)
	numpy.save(directory+"YS_glob", YS_glob)
	if( not(vis_img) ):
		print "Per visualizzare i grafici puoi eseguire\n python grafica.py."
		print "------------------------------------------------------------------------"

