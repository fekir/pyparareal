#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
 pyparareal: un codice python per testare il metodo parareal

 Copyright (C) 2013-2014 Federico Paolo Kircheis

 This file is part of pyparareal.

 pypareal is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Librerie
import math								# contiene operatori matematici, come ad esempio exp
import numpy							# contiene comandi simili a matlab, ad esempio power, zeros, ...

def ee(f,T,y0):
# T,Y = ee(f,T,y0)
#		f:  funzione di due variabili (t,y) (non per forza come inline)
#		T:  vettore riga dei tempi
#		y0: soluzione in t=0
#output
#		T: vettore dei tempi (riporto nel caso usi un passo adattivo)
#		Y: vettore soluzione approssimata agli istanti contenuti in T
#
# Questa funzione applica il metodo di eulero esplicito (implementata anche come metodo RK)
	dim = numpy.size(y0)
#	T = numpy.linspace(t0,tmax,num_int+1)
#	h = (tmax-t0+0.0)/num_int
#	Y = numpy.zeros((dim,num_int+1))
	Y = numpy.zeros((dim,numpy.size(T)))
	Y[:,0] = y0;
	for n in range(0,numpy.size(T)-1):
		Y[:,n+1] = Y[:,n]+(T[n+1]-T[n])*f(T[n],Y[:,n])

	return T, Y

def eiptofisso(f,t0,tmax,num_int,y0,toll=1e-16,nitmax=100):
# T,Y = eiptofisso(f,t0,tmax,num_int,y0,toll,nitmax)
# Input
#		f:	     funzione di due variabili (t,y)
#		T:      vettore riga dei tempi
#		y0:     soluzione in t=0
#		toll:   tolleranza (uso punto fisso), opzionale
#		nitmax: numero massimo di terate (uso punto fisso), opzionale
# Output
#		T: vettore dei tempi (riporto nel caso usi un passo adattivo)
#		Y: vettore soluzione approssimata agli istanti contenuti in T
# usa punto fisso, ma da problemi di convergenza, richiede condizioni più stringenti di EE
	dim = numpy.size(y0)
	T = numpy.linspace(t0,tmax,num_int+1)
	h = (tmax-t0+0.0)/num_int
	Y = numpy.zeros((dim,num_int+1))
	Y[:,0] = y0
	nit=numpy.zeros(num_int+1)

	for n in range(0,num_int):
		err=toll+1
		it=0
		Uv=Y[:,n]
		while((it<nitmax) & (err>toll)):  # creo Un tramite metodo di punto fisso --> meglio usare bisezione
			Un=Y[:,n]+h*f(T[n+1],Uv)
			err=max(abs(Un-Uv))
			it=it+1
			Uv=Un
		#end while
		if ((it>=nitmax) & (err>toll)):
			print 'ERRORE: metodo punto fisso non converge!'
		#	return T, Y, nit
		Y[:,n+1] = Un
		nit[n] = it

	return T, Y#, nit

def RK45(f,T,y0,dfy,toll=1e-12, nitmax=10, hmax=1):
# da risultati leggermente diversi dalla versione Octave
	a=[0.0,1.0/4,3.0/8,12.0/13,1.0,0.5]
	B=[[0.0, 0.0, 0.0, 0.0, 0.0, 0.0], [0.25, 0.0, 0.0, 0.0, 0.0, 0.0], [3.0/32, 9.0/32, 0.0, 0.0, 0.0, 0.0], [1932.0/2197, -7200.0/2197, 7296.0/2197, 0.0, 0.0, 0.0], [439.0/216, -8.0, 3680.0/513, -845.0/4104, 0.0, 0.0], [-8.0/27, 2.0, -3544.0/2565, 1859.0/4104, -11.0/40, 0.0] ]
	c1=[25.0/216, 0.0, 1408.0/2565, 2197.0/4104, -1.0/5, 0.0]
	c2=[16.0/135, 0.0, 6656.0/12825, 28561.0/56430, -9.0/50, 2.0/55]

	dim = numpy.size(y0)
	Y = numpy.zeros((dim,numpy.size(T)))
	Y[:,0] = y0
	Nc = numpy.zeros(numpy.size(T))

	h = hmin = T[1]-T[0]
	t0=T[0]
	T = numpy.zeros(numpy.size(T))
	T[0]=t0
	q = 1
	nc = -1
	p = 4

	ns = numpy.size(a)
	K = numpy.zeros([dim,ns])

	n=0
	while (n<numpy.size(T)-1):
		nc +=1
		h = min (max(h*q,hmin), hmax)
		for r in range(0,ns):
			K[:,r] = f( T[n]+a[r]*h , Y[:,n]+h*numpy.dot(K,numpy.transpose(B[r][:])) )

		ERR = numpy.linalg.norm(h*numpy.dot(K, numpy.transpose(c1)-numpy.transpose(c2) ),numpy.inf)
		q = ((toll+0.0)/ERR)**(1.0/(p+1))
		if ( (ERR<toll) | (h<=hmin)):
			T[n+1]=T[n]+h		#incremento il passo
			#Y1[:,n+1]=Y1[:,n]+h*numpy.dot(K,numpy.transpose(c1))
			Y[:,n+1]=Y[:,n]+h*numpy.dot(K,numpy.transpose(c2))
			if (h==hmin):
				Nc[n]=-10;
			else:
				Nc[n]=nc;
			#end
			nc=-1;
			n=n+1;
		#end
	#end for n in range
	return T,Y

def RKada(f,T,y0,B,a,c,ordine,esplicito, dfy, toll=1e-12, nitmax=100, hmin = 1e-2, hmax=1):
# Runge Kutta Adattivo con passo h, h/2, testare prima versione matlab che è poco chiara
# il prb di rk45 è che usa metodi espliciti --> poco stabile, qui richiamo RK, quindi a priori anche implicito
	dim = numpy.size(y0)
	Y = numpy.zeros((dim,numpy.size(T)))
	Y[:,0] = y0
	Nc = numpy.zeros(numpy.size(T))

	h = T[1]-T[0]
	t0   = T[0]
	T    = numpy.zeros(numpy.size(T))
	T[0] = t0
	q    = 1
	nc   = -1
	p    = ordine

	n=0
	while (n<numpy.size(T)-1):
		nc +=1
		h = min (max(h*q,hmin), hmax)

		T1,Y1 = RK(f,[T[n],T[n]+h],Y[:,n],B,a,c,esplicito, dfy, toll=1e-12, nitmax=100)
		T2,Y2 = RK(f,[T[n],T[n]+h/2,T[n]+h, ],Y[:,n],B,a,c,esplicito, dfy, toll=1e-12, nitmax=100)

		ERR = numpy.linalg.norm((Y1[:,-1]-Y2[:,-1]),numpy.inf)/(2**p-1.0)
		q = ((toll+0.0)/(ERR*(2**p)))**(1.0/(p+1))

		if ( (ERR<toll) | (h<=hmin)):
			T[n+1]=T[n]+h		#incremento il passo
			Y[:,n+1]=Y2[:,-1]
			if (h==hmin):
				Nc[n]=-10;
			else:
				Nc[n]=nc;
			#end
			nc=-1;
			n=n+1;
		#end
	#end for n in range
	return T,Y

def RK(f,T,y0,B,a,c,esplicito, dfy, toll=1e-12, nitmax=100):
#def RK(f,t0,tmax,num_int,y0,B,a,c,esplicito, dfy, toll=1e-12, nitmax=100):
# T,Y = RKesp(f,T,y0,a,B,c)
# Input:
#		f:     funzione di due variabili (t,y)
#		T:     vettore riga dei tempi
#		y0:    soluzione in t=0
#		a,B,c: parti di una matrice di Butcher, B é la matrice, c il  vettore la cui somma da 1
	dim = numpy.size(y0)
	Y = numpy.zeros((dim,numpy.size(T)))
	Y[:,0] = y0

	ns = numpy.size(a)
	K = numpy.zeros([dim,ns])
	if(esplicito==True):
		for n in range(0,numpy.size(T)-1):
			h = T[n+1]-T[n]+0.0
			for r in range(0,ns):
				K[:,r] = f( T[n]+a[r]*h , Y[:,n]+h*numpy.dot(K,numpy.transpose(B[r][:])) )

			Y[:,n+1] = Y[:,n] + h*numpy.dot(K,numpy.transpose(c))
		#end for n in range
	elif(esplicito==False):
		bd = numpy.diag(B)
		B  = B - numpy.diag(bd)
		for n in range(0,numpy.size(T)-1):
			h = T[n+1]-T[n]+0.0
			for r in range(0,ns):
				it=0
				err=toll+1
				u=K[:,r]
				tnr=T[n]+a[r]*h
				aux=Y[:,n]+h*numpy.dot(K,numpy.transpose(B[r][:]))
				while ( (it<nitmax) & (err>toll) ):
					J = numpy.eye(dim)-h*bd[r]*numpy.array(dfy(tnr,aux+h*bd[r]*u))
					tn = f(tnr,aux+h*bd[r]*u)-u
					delta = numpy.linalg.solve(J, tn)
					err = numpy.linalg.norm(delta,numpy.inf);
					it = it+1
					u = u + delta
				#end while
				K[:,r] = u
				#nit[n,r]=it
				if ( (it==nitmax) & (err>toll) ):
					print '########################################################################'
					print '# Metodo RK implicito ha avuto problemi a convergere                   #'
					print '########################################################################'
					#return
				#end if
			#end for r=1:ns
			Y[:,n+1] = Y[:,n] + h*numpy.dot(K,numpy.transpose(c))
		#end for n=1:length(T)-1
	#end if
	return T,Y

def RKcomp(metodo):
#passare nome metodo, qui ve ne sono altri: https://en.wikipedia.org/wiki/List_of_Runge%E2%80%93Kutta_methods
# Metodi espliciti
	if (metodo=='EE'):
		B=[[0]]
		a=[1]
		c=[1]
		ordine=1
		esplicito=True
	elif (metodo=='HEUN'):
		B=[[0, 0],[1, 0]]
		a=[0, 1]
		c=[0.5,0.5]
		ordine=1
		esplicito=True
	elif (metodo=='EUL_MOD'):
		B=[[0, 0],[0.5, 0]]
		a=[0, 0.5]
		c=[0, 1]
		ordine=1
		esplicito=True
	elif (metodo=='GILL'):
		B=[[0, 0, 0, 0], [1.0/2, 0, 0, 0], [(numpy.sqrt(2)-1)/3, (2-numpy.sqrt(2))/2, 0, 0], [0, -numpy.sqrt(2)/2, 1+numpy.sqrt(2), 0] ]
		a=[0, 1.0/2, 1.0/2, 1]
		c=[1.0/6, (2-numpy.sqrt(2))/6, (2+numpy.sqrt(2))/6, 1.0/6]
		ordine=1
		esplicito=True
	elif (metodo=='OTTIMA'):
		B=[[0, 0], [2.0/3, 0] ]
		a=[0, 2.0/3]
		c=[1.0/4, 3.0/4]
		ordine=2
		esplicito=True
	elif (metodo=='?'):
		B=[[0, 0, 0], [1.0/3, 0, 0], [0, 2.0/3, 0] ]
		a=[0, 1.0/3, 2.0/3]
		c=[1.0/4, 0, 3.0/4]
		ordine=3;
		esplicito=True
	elif (metodo=='NYSTROM'):
		B=[[0, 0, 0], [2.0/3, 0, 0], [0, 2.0/3, 0] ]
		a=[0, 0, 2.0/3]
		c=[2.0/8, 3.0/8, 3.0/8]
		ordine=3;
		esplicito=True
	elif (metodo=='RK3'):
		B=[[0, 0, 0], [1.0/2, 0, 0], [-1, 2, 0] ]
		a=[0, 1.0/2, 1]
		c=[1.0/6, 4.0/6, 1.0/6]
		ordine=3
		esplicito=True
	elif (metodo=='RK4'):
		B=[[0, 0, 0, 0], [1.0/2, 0, 0, 0], [0, 1.0/2, 0, 0], [0, 0, 1, 0] ]
		a=[0, 1.0/2, 1.0/2, 1]
		c=[1.0/6, 1.0/3, 1.0/3, 1.0/6]
		ordine=4;
		esplicito=True
	elif (metodo=='KUTTA'):
		B=[[0, 0, 0, 0], [1.0/3, 0, 0, 0], [-1.0/3, 1, 0, 0], [1, -1, 1, 0]]
		a=[0, 1.0/3, 2.0/3, 1]
		c=[1.0/8, 3.0/8, 3.0/8, 1.0/8]
		ordine=4
		esplicito=True
	elif (metodo=='MERSON'):
		B=[[0, 0, 0, 0, 0], [1.0/3, 0, 0, 0, 0], [1.0/6, 1.0/6, 0, 0, 0], [1.0/8, 0, 3.0/8, 0, 0], [1.0/2, 0, -3.0/2, 2, 0] ]
		a=[0, 1.0/3, 1.0/3, 1.0/2, 1]
		c=[1.0/6, 0, 0, 2.0/3, 1.0/6]
		ordine=4
		esplicito=True
# Metodi Impliciti
	elif (metodo=='EI'):
		B=[[1]]
		a=[1]
		c=[1]
		ordine=1
		esplicito=False
	elif (metodo=='TRAPEZI'):
		B=[[0,0],[0,1]]
		a=[0, 1]
		c=[0.5,0.5]
		ordine=2
		esplicito=False
	elif (metodo=='GAUSSLOBATTO1'):
		B=[[0,0],[0.5,0.5]]
		a=[0, 1]
		c=[0.5,0.5]
		ordine=2
		esplicito=False
	elif (metodo=='GAUSSLOBATTO2'):
		B=[[0.5,0],[0.5,0]]
		a=[0, 1]
		c=[0.5,0.5]
		ordine=2
		esplicito=False
	elif (metodo=='HAMMER'):
		B=[[0,0],[1.0/3,1.0/3]]
		a=[0, 2.0/3]
		c=[1.0/4,3.0/4]
		ordine=3
		esplicito=False
	elif (metodo=='DIRK1'):
		k=2*numpy.cos(1.0/18*numpy.pi)/numpy.sqrt(3)
		B=[[(1+k)/2,0,0], [-k/2, (1+k)/2 ,0], [1.0+k, -1-2*k, (1+k)/2]]
		a=[(1.0+k)/2, 1.0/2, (1.0-k)/2]
		c=[1/(6*k*k), 1-1/(3*k*k), 1/(6*k*k)]
		ordine=4
		esplicito=False
	elif (metodo=='DIRK2'):
		k=-2*numpy.cos(5.0/18*numpy.pi)/numpy.sqrt(3)
		B=[[(1+k)/2,0,0], [-k/2, (1+k)/2 ,0], [1+k, -1-2*k, (1+k)/2]]
		a=[(1+k)/2, 1.0/2, (1-k)/2]
		c=[1/(6*k*k), 1-1/(3*k*k), 1.0/(6*k*k)]
		ordine=4
		esplicito=False
	elif (metodo=='DIRK3'):
		k=-2*numpy.cos(7.0/18*numpy.pi)/numpy.sqrt(3);
		B=[[(1+k)/2,0,0], [-k/2, (1+k)/2 ,0], [1+k, -1-2*k, (1+k)/2]]
		a=[(1+k)/2, 1.0/2, (1-k)/2]
		c=[1/(6*k*k), 1-1/(3*k*k), 1.0/(6*k*k)]
		ordine=4
		esplicito=False
	elif (metodo=='BUTCHERLOBATTO'):
		B=[[0,0,0], [0.25, 0.25 ,0], [0, 1, 0] ]
		a=[0, 1.0/2, 0]
		c=[1.0/6, 2.0/3, 1.0/6]
		ordine=4
		esplicito=False
	return B,a,c,ordine,esplicito
