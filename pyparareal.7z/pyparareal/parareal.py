#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
 pyparareal: un codice python per testare il metodo parareal

 Copyright (C) 2013-2014 Federico Paolo Kircheis

 This file is part of pyparareal.

 pypareal is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Librerie
import math								# contiene operatori matematici, come ad esempio exp
import numpy							# contiene comandi simili a matlab, ad esempio power, zeros, ...
from copy import copy, deepcopy	# per copiare array, altrimenti è un riferimento
from mpi4py import MPI				# per lavorare con MPI
from matrix2latex import matrix2latex	# per scrittura tabelle latex

size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
name = MPI.Get_processor_name()

########################################################################
# Funzioni del metodo parareal
def seq_update(f,T,YG,y0,YG_old,YF_end,G):
	# update, da fare in sequenziale
	# ritorna intero vettore aggiornato
	dim     = numpy.size(y0)
	YG[:,0] = y0
	YG_new  = numpy.zeros((dim,numpy.size(T)))
	for j in range(1,numpy.size(T)):
		T_tmp = numpy.linspace(T[j-1],T[j],1+1) # metodo ad 1 passo
		T_tmp,YG_new_tmp = G(f,T_tmp,YG[:,j-1])
		YG_new[:,j] = YG_new_tmp[:,-1]
		YG[:,j] = YG_new[:,j] + YF_end[:][j] - YG_old[:,j]
	return YG_new, YG


########################################################################
# Metodo parareal
def kernel(f,t0,tmax,y0,num_int,num_intF,kmax,I,G,F,toll=-1):
	# codice parareal
	# ritorna YF e YG su tutti gli intervalli di ogni iterata [implementato solo YG]

	num_int   = size		# così che ogni proc ha un intervallo, size è globale, non passato come argomento
	dim       = numpy.size(y0)
	diff_iter = toll+1	# differenza tra iterate, da confrontare con tolleranza

	if (rank==0):
		# creo dati iniziali
		T         = numpy.linspace(t0, tmax, num_int+1)
		T,YG      = I(f,T,y0)				# approssimo in modo grossolano la soluzione - creo dati iniziali
		part      = numpy.zeros((num_int,2))
		for j in range(0,num_int):
			part[j,:] = [T[:-1][j], T[1:][j]]

		# creo dati per prossime iterate
		YG_new = numpy.zeros((dim,numpy.size(T)))
		YG_old = deepcopy(YG)

		T_glob = T
		Y_glob = numpy.zeros((dim,kmax+1,numpy.size(T)))
		#TF_glob è definito alla fine
		#YF_glob è da definire, è array che contiene array...
		YF_glob = numpy.zeros((dim,kmax,num_intF+1,num_int))

		Y_glob[:,0,:] = deepcopy(YG)
	else: #creo spazio per dati da ricevere
		part      = None
		YG        = None

	part  = MPI.COMM_WORLD.scatter(part, root=0)
	YG    = MPI.COMM_WORLD.bcast(YG, root=0)    #bcast, ma con YG ho dei problemi

	# dopo aver calcolata la sol grossolana, e notificato i dati iniziali, devo iterare
	condition = True
	k = 0
	if (rank==0):
		print 'Criterio arresto:' # dopo stampa quale criterio è stato usato

	while (condition):
		k += 1

		# se ho k=n, inutile ricalcolare fine perchè metodo è esatto, uso rank+1 perchè i proc iniziano da 0, mentre k da 1
		if (k<=rank+1):
			TF    = numpy.linspace(part[0],part[1],num_intF+1)
			TF,YF = F(f,TF,YG[:,rank])
		#else: ha in memoria i dati della iterata precedente

		# NOTA! : con le gather creo delle liste! --> YF_end viene trasformato da array in lista
		YF_end = MPI.COMM_WORLD.gather(YF[:,-1], root=0)
		#TFF    = MPI.COMM_WORLD.gather(TF, root=0)				# ha dimensione (num_int,num_intF), la mando fuori dal ciclo
		YFF    = MPI.COMM_WORLD.gather(YF, root=0)				# ha dimensione ~(num_int,dim,num_intF), lista che contiene array!

		# dopo aver raccolto la soluzione fine devo aggiornare i dati iniziali

		if (rank==0):
			for j in range(0,num_int):
				YF_glob[:,k-1,:,j] = YFF[j][:]
			YF_end = [y0]+YF_end # sto aggiungendo un elemento all'inizio della lista!

			YG[:,0]    = y0
			YG_new, YG = seq_update(f,T,YG,y0,YG_old,YF_end,G)
			YG_old     = deepcopy(YG_new)

			Y_glob[:,k,:] = deepcopy(YG)
			diff_iter     = numpy.max(numpy.abs(YG -Y_glob[:,k-1,:]))
		#end if (rank==0)

		# appena una condizione è falsa esco dal ciclo
		if (rank==0):
			if (k>=size):
				condition &= False					# non ha senso fare più iterate
				print ' - metodo esatto (%d iterate)' % (k)
			if (k >= kmax):
				condition &= False					# altrimenti fuori dal range
				print ' - raggiunto kmax (%d iterate)' % (k)
			if (diff_iter<toll):
				condition &= False 					# ho raggiunto precisione desiderata
				print ' - raggiunta tolleranza richiesta, ho %f < %f con %d iterate' %(diff_iter,toll, k)
		#end if check condition
		condition = MPI.COMM_WORLD.bcast(condition, root=0) # notifico se andare avanti
		if (condition==True):
			YG = MPI.COMM_WORLD.bcast(YG, root=0)
	#end while (condition)

	TFF = MPI.COMM_WORLD.gather(TF, root=0)
	if(rank==0): # ridurre Y_glob, YF_glob se non raggiungo kmax
		print "------------------------------------------------------------------------"
		TF_glob = TFF
		return T_glob,Y_glob[:,0:k+1,:],TF_glob,YF_glob[:,0:k,:]
		  #restituisco un sottoarray che contiene fino alla k'esima iterate, eventuali ulteriori elementi non sono significativi
	else:
		return 0,0,0,0
