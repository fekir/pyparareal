#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Librerie per avere strumenti matematici stile matlab
import math								# contiene operatori come ad esempio exp
import numpy							# contiene comandi simili a matlab
#from matplotlib import pyplot		# per fare plot come matlab


# Librerie usate in hello world per mpi
from mpi4py import MPI
import sys

size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
name = MPI.Get_processor_name()

# pass explicit MPI datatypes
if rank == 0:
	data = numpy.arange(10, dtype='i')
	#print data
	MPI.COMM_WORLD.Send([data, MPI.INT], dest=1, tag=0)
elif rank == 1:
	data = numpy.empty(10, dtype='i')
	#print data
	MPI.COMM_WORLD.Recv([data, MPI.INT], source=0, tag=0)
	print data

"""
# automatic MPI datatype discovery
if rank == 0:
	data = numpy.arange(100, dtype=numpy.float64)
	#print data
	MPI.COMM_WORLD.Send(data, dest=1, tag=13)
elif rank == 1:
	data = numpy.empty(100, dtype=numpy.float64)
	MPI.COMM_WORLD.Recv(data, source=0, tag=13)
	print data
"""
