#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Librerie per avere strumenti matematici stile matlab
import math								# contiene operatori come ad esempio exp
import numpy							# contiene comandi simili a matlab
#from matplotlib import pyplot		# per fare plot come matlab

# Librerie per mpi
from mpi4py import MPI

size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
name = MPI.Get_processor_name()

dim=2

if (rank==0):
	T         = numpy.linspace(0, size, size+1)
	YG        = numpy.zeros((dim,numpy.size(T)))
	print YG[:,0]
	data      = numpy.zeros((size,2+dim))
	t0_send   = T[:-1]
	tmax_send = T[1:]
	j=0
	print [T[:-1][j], T[1:][j], YG[:,j]]
	print data[j,:]
	for j in range(0,2+dim):
		data[j,:] = [T[:-1][j], T[1:][j], YG[:,j][:]]

	print data
else:
	t0_send   = None
	tmax_send = None
	data      = None

#tF0   = 0
#tFmax = 0

#tF0   = MPI.COMM_WORLD.scatter(t0_send, root=0)
#tFmax = MPI.COMM_WORLD.scatter(tmax_send, root=0)			# combinarle insieme
data  = MPI.COMM_WORLD.scatter(data, root=0)			# combinarle insieme
print data
