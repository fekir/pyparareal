#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Librerie per avere strumenti matematici stile matlab
import math								# contiene operatori come ad esempio exp
import numpy							# contiene comandi simili a matlab
#from matplotlib import pyplot		# per fare plot come matlab

# Librerie per mpi
from mpi4py import MPI

size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
name = MPI.Get_processor_name()

comm = MPI.COMM_WORLD
sendmsg = MPI.COMM_WORLD**2
recvmsg1 = MPI.COMM_WORLD.gather(sendmsg, root=0)
recvmsg2 = MPI.COMM_WORLD.allgather(sendmsg)

# stampa dei messaggi ricevuti
print recvmsg1
#print recvmsg2
