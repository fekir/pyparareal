#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Librerie per avere strumenti matematici stile matlab
import math								# contiene operatori come ad esempio exp
import numpy							# contiene comandi simili a matlab
#from matplotlib import pyplot		# per fare plot come matlab

# Librerie per mpi
from mpi4py import MPI

size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
name = MPI.Get_processor_name()


if rank == 0:
	data = {'key1' : [7, 2.72, 2+3j], 'key2' : ( 'abc', 'xyz')}
	#data = numpy.arange(2*size, dtype='i')
	print data
else:
	data = None
	T=None

# mando bcast
data = MPI.COMM_WORLD.bcast(data, root=0)
print data
#printo nome e bcast
#print "Helloworld! I am process %d of %d on %s." % (rank, size, name)
#print data[rank]
