#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Librerie per avere strumenti matematici stile matlab
import math								# contiene operatori come ad esempio exp
#import numpy							# contiene comandi simili a matlab
#from matplotlib import pyplot		# per fare plot come matlab


# Librerie usate in hello world per mpi
from mpi4py import MPI

size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
name = MPI.Get_processor_name()

print "Helloworld! I am process %d of %d on %s." % (rank, size, name)
